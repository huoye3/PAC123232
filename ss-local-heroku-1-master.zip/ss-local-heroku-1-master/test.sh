rm -rf .DS_Store
git add  -A
git commit -m 'new commit'
git push -u origin master
