#!/bin/sh
node /Users/alextsui/.git/ss-nodejs/local.js -c /Users/alextsui/.git/ss-nodejs/config.json
